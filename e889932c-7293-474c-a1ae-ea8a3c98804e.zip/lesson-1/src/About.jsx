import React from 'react'

export const About = () => {
  return <>About</>
}
